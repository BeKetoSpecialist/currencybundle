=== WooCommerce Product Bundles ===

Contributors: SomewhereWarm
Tags: woocommerce, product, bundle, bundles, kits, simple, variable, configurable
Requires at least: 6.2
Tested up to: 6.6
Stable tag: 8.1.1
WC requires at least: 8.2
WC tested up to: 9.2
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Offer product bundles, bulk discount packages, and assembled products.

== Description ==

Create assembled products and product bundles by grouping simple, variable and subscription products.

Looking for help? Read the full documentation [here](http://woocommerce.com/document/bundles/).
